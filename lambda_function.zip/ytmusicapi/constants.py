YTM_DOMAIN = 'https://music.youtube.com'
YTM_BASE_API = YTM_DOMAIN + '/youtubei/v1/'
YTM_PARAMS = '?alt=json'
YTM_PARAMS_KEY = "&key=AIzaSyC9XL3ZjWddXya6X74dJoCTL-WEYFDNX30"
USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:88.0) Gecko/20100101 Firefox/88.0'
OAUTH_CLIENT_ID = "861556708454-d6dlm3lh05idd8npek18k6be8ba3oc68.apps.googleusercontent.com"
OAUTH_CLIENT_SECRET = "SboVhoG9s0rNafixCSGGKXAT"
OAUTH_SCOPE = "https://www.googleapis.com/auth/youtube"
OAUTH_CODE_URL = "https://www.youtube.com/o/oauth2/device/code"
OAUTH_TOKEN_URL = "https://oauth2.googleapis.com/token"
OAUTH_USER_AGENT = USER_AGENT + " Cobalt/Version"
